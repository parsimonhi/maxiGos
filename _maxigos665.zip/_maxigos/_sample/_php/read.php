<?php
function sgf_file_get_contents($f,$docCharset="UTF-8")
{
	$content=file_get_contents($f);
	if (preg_match("/CA\\[([^\\]]*)\\]/",$content,$m)) $charset=$m[1];else $charset="ISO-8859-1";
	if ($charset!=$docCharset) $content=mb_convert_encoding($content,$docCharset,$charset);
	return $content;
}
?>
