// maxiGos v6.65 > tactigoPatch.js

if (typeof mxG.G.prototype.createTactigoPatch=='undefined'){

mxG.G.prototype.drawStone4Tactigo=function(cx,nat,d)
{
	var r=d/2,c1,c2;
	cx.beginPath();
	cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
	if (this.in3dOn)
	{
		var rG;
		if (nat=="B")
		{
			cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
			cx.fillStyle="#333";
			cx.fill();
			rG=cx.createRadialGradient(1.05*r,0.75*r,0.65*r,1.05*r,1.25*r,2*r);
			rG.addColorStop(0,"rgba(255,255,255,0.5)");
			rG.addColorStop(0.2,"rgba(51,51,51,0.75)");
			rG.addColorStop(1,"rgba(0,0,0,0.75)");
			cx.fillStyle=rG;
			cx.fill();
			rG=cx.createRadialGradient(1.25*r,1.25*r,r,1.5*r,1.75*r,r);
			rG.addColorStop(0,"rgba(17,17,17,0.1)");
			rG.addColorStop(0.5,"rgba(17,17,17,0.6)");
			rG.addColorStop(1,"rgba(17,17,17,0.8)");
			cx.fillStyle=rG;
			cx.fill();
		}
		else
		{
			rG=cx.createRadialGradient(0.75*r,0.75*r,0.25*r,0.75*r,1.00*r,2*r);
			rG.addColorStop(0,"#fff");
			rG.addColorStop(0.3,"#ddd");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
		}
	}
	else
	{
		if (nat=="B")
		{
			c1=this.blackStoneColor;
			c2=this.blackStoneBorderColor?this.blackStoneBorderColor:"#000";
		}
		else
		{
			c1=this.whiteStoneColor;
			c2=this.whiteStoneBorderColor?this.whiteStoneBorderColor:"#000";
		}
		cx.fillStyle=c1;
		cx.fill();
		cx.strokeStyle=c2;
		cx.lineWidth=this.lw;
		cx.stroke();
	}
};

mxG.G.prototype.createTactigoPatch=function()
{
	this.drawStone=this.drawStone4Tactigo;
};

}
