<!DOCTYPE html>
<?php include "../_php/lang.php";?>
<html lang="<?php echo $mxL;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<?php
include "../_php/date.php";
if ($mxL=="fr") $title="Exemple d'utilisation de maxiGos : façon WGo.js";
else if ($mxL=="ja") $title="MaxiGos例・WGo.jsのスタイル";
else if ($mxL=="zh") $title="MaxiGos例子-WGo.js";
else if ($mxL=="zh-tw") $title="MaxiGos例子-WGo.js";
else $title="Sample for maxiGos: WGo.js like";
if ($mxL=="fr") $title2="Façon WGo.js";
else if ($mxL=="ja") $title2="WGo.jsのスタイル";
else if ($mxL=="zh") $title2="WGo.js";
else if ($mxL=="zh-tw") $title2="WGo.js";
else $title2="WGo.js like";
if ($mxL=="fr") $backLabel="Revenir en haut de la page";
else if ($mxL=="ja") $backLabel="トップに戻る";
else if ($mxL=="zh") $backLabel="返回顶部";
else if ($mxL=="zh-tw") $backLabel="返回頂部";
else $backLabel="Back to top";
?>
<link rel="stylesheet" href="../_css/mini.css" type="text/css">
<style>
body {font-family:sans-serif;}
div.main>h1 {font-size:1.5em;background:#000;color:#fff;margin:0;padding:0.5em;}
div.main>h1 a {color:#fff;text-decoration:none;}
div.main>h1 a:hover {text-decoration:underline;}
div.main>h2 {font-size:1.25em;margin:0;padding:0.5em;}
div.main>p {padding:0.5em;}
div.menu a:hover,
ul.sampleList li a:hover,
ul.sampleList li.currentSample a:hover {color:#c33 !important;}
</style>
<title><?php print $title;?></title>
</head>
<body>
<?php $maxiGosDirPath="../../";include "../_php/sample.php";?>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
<div class="main">
<h1><a href="http://wgo.waltheri.net/"><?php print $title2;?></a></h1>
<?php if ($mxL=="fr") {?>
<p>Cet exemple montre des lecteurs maxiGos variés ayant un thème similaire au remarquable <a href="http://wgo.waltheri.net/">WGo.js</a>.
Cependant, le code de cet exemple n'a rien en commun avec celui de WGo.js, excepté quelques règles css et images.</p>
<?php } else {?>
<p>This sample shows various maxiGos players that have a theme similar to the remarquable <a href="http://wgo.waltheri.net/">WGo.js</a>.
However, the code of this sample has nothing in common with the code of WGo.js, excepting some css rules and images.</p>
<?php }?>
<h2 lang="en">Basic</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/basic.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Comment</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
<h2 lang="en">Diagram</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Game</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/game.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Problem</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Tree</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/wgo/_cfg/tree.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
</body>
</html>
