// maxiGos v6.63 > wgoPatch.js

if (typeof mxG.G.prototype.createWGoPatch=='undefined'){

mxG.Z.fr["Comments"]="Commentaires";
mxG.Z.fr["Game tree"]="Arbre des coups";

mxG.G.prototype.drawStone4WGo=function(cx,nat,d)
{
	var r=d/2,c1,c2;
	cx.beginPath();
	cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
	if (this.in3dOn)
	{
		var zx=0.8,zy=0.5,x1,y1,rG;
		x1=zx*r;
		y1=zy*r;
		if (nat=="B")
		{
			rG=cx.createRadialGradient(0.5*r,0.5*r,0.05*r,0.5*r,0.5*r,2*r);
			rG.addColorStop(0,"#666");
			rG.addColorStop(0.3,"#222");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
		}
		else
		{
			rG=cx.createRadialGradient(x1,y1,0.2*r,x1,y1,3*r);
			rG.addColorStop(0,"#fff");
			rG.addColorStop(0.3,"#ccc");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
			cx.beginPath();
			cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
			cx.strokeStyle="rgba(0,0,0,0.1)";
			cx.lineWidth=this.lw;
			cx.stroke();
		}
	}
	else
	{
		if (nat=="B")
		{
			c1=this.blackStoneColor;
			c2=this.blackStoneBorderColor?this.blackStoneBorderColor:"#000";
		}
		else
		{
			c1=this.whiteStoneColor;
			c2=this.whiteStoneBorderColor?this.whiteStoneBorderColor:"#000";
		}
		cx.fillStyle=c1;
		cx.fill();
		cx.strokeStyle=c2;
		cx.lineWidth=this.lw;
		cx.stroke();
	}
};

mxG.G.prototype.doAbout4WGo=function()
{
	if (this.gBox=="ShowAbout") {this.hideGBox("ShowAbout");return;}
	if (!this.getE("ShowAboutDiv"))
	{
		var s="";
		s+="<div class=\"mxShowContentDiv\">";
		s+="<h1>maxiGos "+mxG.V+"</h1>";
		s+="<p>Source: <a href=\"http://jeudego.org/maxiGos\">http://jeudego.org/maxiGos</a></p>";
		s+="<p>Theme: <a href=\"http://wgo.waltheri.net/player\">WGo.js</a>, copyright Jan Prokop</p>";
		s+="<p>Configuration: "+this.config+"</p>";
		s+="<p>License: <a href=\"https://opensource.org/licenses/BSD-3-Clause\">BSD</a></p>";
		s+="<p>Copyright 1998-2017 François Mizessyn</p>";
		s+="</div>";
		s+="<div class=\"mxOKDiv\">";
		s+="<button type=\"button\" onclick=\""+this.g+".hideGBox('ShowAbout')\"><span>"+this.local("Close")+"</span></button>";
		s+="</div>";
		this.createGBox("ShowAbout").innerHTML=s;
	}
	this.showGBox("ShowAbout");
};

mxG.G.prototype.createWGoPatch=function()
{
	this.drawStone=this.drawStone4WGo;
	this.doAbout=this.doAbout4WGo;
};

}