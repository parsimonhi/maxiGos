<!DOCTYPE html>
<?php include "../_php/lang.php";?>
<html lang="<?php echo $mxL;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<?php
include "../_php/date.php";
if ($mxL=="fr") $title="Exemple d'utilisation de maxiGos : caméléon";
else if ($mxL=="ja") $title="MaxiGos例・カメレオン";
else if ($mxL=="zh") $title="MaxiGos例子-变色龙";
else if ($mxL=="zh-tw") $title="MaxiGos例子-變色龍";
else $title="Sample for maxiGos: chameleon";
if ($mxL=="fr") $title2="Caméléon";
else if ($mxL=="ja") $title2="カメレオン";
else if ($mxL=="zh") $title2="变色龙";
else if ($mxL=="zh-tw") $title2="變色龍";
else $title2="Chameleon";
if ($mxL=="fr") $backLabel="Revenir en haut de la page";
else if ($mxL=="ja") $backLabel="トップに戻る";
else if ($mxL=="zh") $backLabel="返回顶部";
else if ($mxL=="zh-tw") $backLabel="返回頂部";
else $backLabel="Back to top";
?>
<link rel="stylesheet" href="../_css/mini.css" type="text/css">
<style>
body {font-family:sans-serif;}
div.main>h1 {font-size:1.5em;background:#000;color:#fff;margin:0;padding:0.5em;}
div.main>h2 {font-size:1.25em;margin:0;padding:0.5em;}
div.menu a:hover,
ul.sampleList li a:hover,
ul.sampleList li.currentSample a:hover {color:#f00 !important;}
.toto {text-align:center;padding-top:1em;}
.toto a {color:#000;}
.toto a:hover {color:#f00;}
body {background:#fff;}

div.main>div {padding:1em 0;}
div.main>div.white {background:#fff;}
div.main>div.light {background:#eee;}
div.main>div.light.red {background:#edc;}
div.main>div.light.blue {background:#bde;}
div.main>div.light.green {background:#deb;}
div.main>div.dark {background:#666;}
div.main>div.dark.red {background:#600;}
div.main>div.dark.blue {background:#006;}
div.main>div.dark.green {background:#060;}

div.main>div.dark div.mxChameleonGlobalBoxDiv {color:#fff;}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxGobanDiv {color:#000;}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxShowContentDiv {color:#fff;}

div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button div:before,
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button div:after
{
	border-color:transparent #fff;
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button:focus div:before,
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button:focus div:after
{
	border-color:transparent #f00;
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button[disabled] div:before,
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv button[disabled] div:after
{
	border-color:transparent rgba(255,255,255,0.3);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxButtonsDiv,
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxNavigationDiv,
div.main>div.dark div.mxChameleonGlobalBoxDiv.mxProblemGlobalBoxDiv div.mxSolveDiv
{
	background:rgba(255,255,255,0.30);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxCommentDiv
{
	background:rgba(255,255,255,0.20);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv.mxTreeGlobalBoxDiv div.mxCommentDiv
{
	border-bottom:1px solid rgba(255,255,255,0.50);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxTreeDiv
{
	background:rgba(255,255,255,0.20);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxShowContentDiv
{
	background:rgba(255,255,255,0.20);
}
div.main>div.dark div.mxChameleonGlobalBoxDiv div.mxOKDiv
{
	background:rgba(255,255,255,0.40);
}
</style>
<title><?php print $title;?></title>
</head>
<body>
<?php $maxiGosDirPath="../../";include "../_php/sample.php";?>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
<div class="main">
<h1><?php print $title2;?></h1>
<h2 lang="en">Basic white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/basic.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Basic light</h2>
<div class="chameleon light">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/basic.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Basic dark</h2>
<div class="chameleon dark">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/basic.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Comment white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Comment light</h2>
<div class="chameleon light red">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Comment dark</h2>
<div class="chameleon dark red">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Comment 2 white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/TV9x9-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Comment 2 light</h2>
<div class="chameleon light green">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/TV9x9-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Comment 2 dark</h2>
<div class="chameleon dark green">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/TV9x9-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Diagram white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Diagram light</h2>
<div class="chameleon light">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Diagram dark</h2>
<div class="chameleon dark">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Game white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/game.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Game light</h2>
<div class="chameleon light blue">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/game.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Game dark</h2>
<div class="chameleon dark blue">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/game.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Problem white</h2>
<div class="chameleon white">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Problem light</h2>
<div class="chameleon light red">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Problem dark</h2>
<div class="chameleon dark red">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Tree white</h2>
<div class="chameleon">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/tree.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Tree light</h2>
<div class="chameleon light green">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/tree.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<h2 lang="en">Tree dark</h2>
<div class="chameleon dark green">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/chameleon/_cfg/tree.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
<div class="toto"><a href="chameleon-alone.php">...</a></div>
</div>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
</body>
</html>
