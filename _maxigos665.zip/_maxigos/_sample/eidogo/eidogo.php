<!DOCTYPE html>
<?php include "../_php/lang.php";?>
<html lang="<?php echo $mxL;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<?php
include "../_php/date.php";
$sgfDir="../_sgf/game/";
include "../_php/file.php";
if ($mxL=="fr")
{
	$subtitle="lecteur façon eidogo";
	$title="Exemple d'utilisation de maxiGos : ".$subtitle;
	$intro="Cet exemple montre maxiGos avec un style façon Eidogo (avec la permission de Justin Kramer).";
}
else
{
	$subtitle="eidogo like player";
	$title="Sample for maxiGos: ".$subtitle;
	$intro="This sample shows maxiGos in an Eidogo like style (with permission of Justin Kramer).";
}
?>
<link rel="stylesheet" href="../_css/mini.css" type="text/css">
<style>
body {text-align:center;margin:0;padding:0;}
h1 a {color:#000;}
h1 a:hover {color:#f00;}
p {margin-left:0.25em;margin-right:0.25em;}
</style>
<title><?php print $title;?></title>
</head>
<body>
<?php $maxiGosDirPath="../../";include $maxiGosDirPath."_sample/_php/sample.php";?>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
<h1><a href="http://eidogo.com"><?php print ucFirst($subtitle);?></a></h1>
<p><?php print $intro;?></p>

<h2 lang="en">Comment</h2>
<script src="../../_mgos/sgfplayer.php?mxL=<?php print $mxL;?>&amp;cfg=<?php print urlencode("../_sample/eidogo/_cfg/comment.cfg");?>&amp;sgf=<?php print urlencode("../_sample/_sgf/game/".$sgfTarget);?>"></script>
<?php include "../_php/select.php";?>

<h2 lang="en">Diagram</h2>
<h3>Full view</h3>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/eidogo/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h3>Partial view</h3>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/eidogo/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/joseki/j1.sgf</script>

<h2 lang="en">Problem</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/eidogo/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>

<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
</body>
</html>
