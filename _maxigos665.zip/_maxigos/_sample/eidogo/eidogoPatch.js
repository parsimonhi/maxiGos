// maxiGos v6.64 > eidogoPatch.js

if (typeof mxG.G.prototype.createEidogoPatch=='undefined'){

mxG.G.prototype.refreshGoban4Eidogo=function()
{
	if (this.d!=this.exD) this.drawGoban();
	this.go.style.padding=this.indicesOn?"":"0";
};

mxG.G.prototype.createEidogoPatch=function()
{
	this.refreshGoban=this.refreshGoban4Eidogo;
};

}
