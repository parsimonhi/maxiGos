// maxiGos v6.63 > wikiPatch.js

if (typeof mxG.G.prototype.createWikiPatch=='undefined'){

mxG.G.prototype.drawStone4Wiki=function(cx,nat,d)
{
	var r=d/2,c1,c2;
	cx.beginPath();
	cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
	if (this.in3dOn)
	{
		var zx=0.5,zy=0.5,rG;
		if (nat=="W")
		{
			cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
			cx.fillStyle="#000";
			cx.fill();
			rG=cx.createRadialGradient(0.95*r,0.95*r,0.75*r,r,r,1.2*r);
			rG.addColorStop(0,"#fff");
			rG.addColorStop(0.5,"#999");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
		}
		else if (nat=="B")
		{
			rG=cx.createRadialGradient(0.6*r,0.6*r,0.01*r,0.7*r,0.7*r,2*r);
			rG.addColorStop(0,"#888");
			rG.addColorStop(0.25,"#222");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
		}
	}
	else
	{
		if (nat=="B")
		{
			c1=this.blackStoneColor;
			c2=this.blackStoneBorderColor?this.blackStoneBorderColor:"#000";
		}
		else
		{
			c1=this.whiteStoneColor;
			c2=this.whiteStoneBorderColor?this.whiteStoneBorderColor:"#000";
		}
		cx.fillStyle=c1;
		cx.fill();
		cx.strokeStyle=c2;
		cx.lineWidth=this.lw;
		cx.stroke();
	}
};

mxG.G.prototype.createWikiPatch=function()
{
	this.drawStone=this.drawStone4Wiki;
};

}
