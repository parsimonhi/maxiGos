<!DOCTYPE html>
<?php include "../_php/lang.php";?>
<html lang="<?php echo $mxL;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<?php
include "../_php/date.php";
if ($mxL=="fr") $title="Exemple d'utilisation de maxiGos : ambiance troyenne";
else if ($mxL=="ja") $title="MaxiGos例・Troyesのスタイル";
else if ($mxL=="zh") $title="MaxiGos例子-Troyes";
else if ($mxL=="zh-tw") $title="MaxiGos例子-Troyes";
else $title="Sample for maxiGos: troyes style";
if ($mxL=="fr") $title2="Ambiance troyenne";
else if ($mxL=="ja") $title2="Troyesのスタイル";
else if ($mxL=="zh") $title2="Troyes";
else if ($mxL=="zh-tw") $title2="Troyes";
else $title2="Troyes style";
if ($mxL=="fr") $backLabel="Revenir en haut de la page";
else if ($mxL=="ja") $backLabel="トップに戻る";
else if ($mxL=="zh") $backLabel="返回顶部";
else if ($mxL=="zh-tw") $backLabel="返回頂部";
else $backLabel="Back to top";
?>
<link rel="stylesheet" href="../_css/mini.css" type="text/css">
<style>
body {font-family:sans-serif;background:#ecdfc2;color:#141412;}
div.main>h1 {font-size:3em;margin:0;padding:0.5rem;}
div.main>h1 a {color:#007ac1;text-decoration:none;}
div.main>h1 a:hover {text-decoration:underline;}
div.content>h2 {font-size:1.25em;margin:0;padding:0.5rem 0;}
div.menu {background:#f7f5e7;color:#141454;text-align:left;padding:0;}
div.menu span {display:inline-block;padding:0;}
div.menu a {display:inline-block;height:2em;line-height:2em;padding:0.5em;text-decoration:none;}
div.menu a:hover,
ul.sampleList li a:hover,
ul.sampleList li.currentSample a:hover {color:#fffff7 !important;background:#220e10 !important;}
div.content {width:50em;max-width:90%;margin:0 auto;padding:0.5rem;}
div.big div.mxGobanDiv {font-size:200%;}
div.medium div.mxGobanDiv {font-size:150%;}
div.aside>div.mxGlobalBoxDiv {float:left;margin:0 0.5em 0.5em 0;}
div.aside+p {clear:both;}
@media (max-width:400px)
{
	div.content {max-width:auto;}
}
</style>
<title><?php print $title;?></title>
</head>
<body>
<?php $maxiGosDirPath="../../";include "../_php/sample.php";?>
<div class="main">
<h1><a href="http://troyes-atari.fr/"><?php print $title2;?></a></h1>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
<div class="content">
<h2 lang="en">Basic</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/basic.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Comment</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
<h2 lang="en">Comment 2</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/comment.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/TV9x9-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
<h2 lang="en">Diagrams and figures</h2>
<div class="big">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
GM[1]
CA[UTF-8]
SZ[19]
ST[0]
AW[ji]
AB[jh][ii][jj]
VW[hg:lk]
AP[maxiGos:6.63])
</script>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
GM[1]
CA[UTF-8]
SZ[19]
ST[0]
AW[ji]
AB[jh][ii][jj]
VW[hg:lk]
AP[maxiGos:6.63]
FG[1]
PM[0]
;B[ki])
</script>
</div>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
</p>
<div class="medium aside">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
CA[UTF-8]
GM[1]
SZ[9]
AP[maxiGos:6.63]
AB[da][ea][fa][cb][dc][eb][fc][ed][fd][ee][fe][ge][ef][gf][gg][hf][dg][cg][bg][bh][bi][be][ce][ci]
AW[ch][dh][di][ei][eg][ff][fg][fh][gh][hh][hg][if][ie][he][hd][gd][gc][gb][fb][ga]
FG[1]
TW[eh][fi][gi][ha][hb][hc][hi][ia][ib][ic][id][ig][ih][ii]
TB[aa][ab][ac][ad][ae][af][ag][ah][ai][ba][bb][bc][bd][bf][ca][cc][cd][cf][db][dd][de][df][ec])
</script>
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</div>
<p>
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
</p>
<div>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
CA[UTF-8]
GM[1]
SZ[19]
AP[maxiGos:6.63]
FG[1]
;B[pd];W[dc];B[pp];W[cp])
</script>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
CA[UTF-8]
GM[1]
SZ[19]
AP[maxiGos:6.63]
FG[1]
;B[pd];W[dc];B[pp];W[cp];B[ep]FG[1]PM[1]MN[1]TR[pd][pp])
</script>
</div>
<p>
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, 
totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae 
dicta sunt explicabo. </p>
<div>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
CA[UTF-8]
GM[1]
SZ[19]
AP[maxiGos:6.63]
FG[1]
;B[pd];W[dc];B[pp];W[cp];B[ep]FG[1]PM[1]MN[1]TR[pd][pp]
;W[eq];B[fq];W[dq];B[fp];W[cn]
;B[jp]LB[qf:A][nc:B])
</script>
</div>
<p>
Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, 
sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. 
</p>
<div class="big">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">
(;
FF[4]
CA[UTF-8]
GM[1]
SZ[19]
AW[fq][dp][pp]
AB[hq][kq]
TR[hq][kq]
LB[iq:1][jq:2]
VW[co:qs]
FG[1]
AP[maxiGos:6.63])
</script>
</div>
<p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
</p>
<div class="medium">
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/diagram.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
</div>
<h2 lang="en">Game</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/game.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/blood-vomit-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Problem</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/problem.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/problem/p3-<?php print (in_array($mxL,array("fr","ja","zh","zh-tw"))?$mxL:"en");?>.sgf</script>
<h2 lang="en">Tree</h2>
<script src="../../_mgos/sgfplayer.php?cfg=../_sample/troyes/_cfg/tree.cfg&amp;mxL=<?php echo $mxL;?>">../_sgf/game/mn-bdg-<?php print ($mxL=="fr"?"fr":"en");?>.sgf</script>
</div>
</div>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
</body>
</html>
