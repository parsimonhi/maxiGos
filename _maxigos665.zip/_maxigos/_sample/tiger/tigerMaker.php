<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
body {font-family:Arial,sans-serif;}
h1.top {text-align:center;}
iframe {border:0;margin:0 auto;display:block;}
</style>
</head>
<body>
<?php
// uncomment lines below in order to make the stand-alone player tiger.js
// include_once('../../_php/aloneLib.php');
// makeAlone("_alone/tiger.js","tigerTree.cfg","../../../","en");
?>
<h1 class="top">Make "tiger.js" stand-alone player</h1>
<?php print "<iframe width=\"100%\" height=\"1000\" src=\"../../_alone/aloneViewer.php?mxL="."en"."&amp;s="."../_sample/tiger/_alone/tiger.js"."\"></iframe>\n";?>
</body>
</html>
