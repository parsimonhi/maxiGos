// begin of localization
if (typeof mxG=='undefined') mxG={};
// end of localization