// maxiGos v6.64 > mgosScore.js

if (typeof mxG.G.prototype.createScore=='undefined'){

mxG.Z.fr["Score"]="Score";
mxG.Z.fr["Black:"]="Noir :";
mxG.Z.fr["White:"]="Blanc :";
mxG.Z.fr["chinese rules"]="règle chinoise";
mxG.Z.fr["AGA rules"]="règle AGA";
mxG.Z.fr["Ing rules"]="règle Ing";
mxG.Z.fr["New-Zeland rules"]="règle néo-zélandaise";
mxG.Z.fr["japanese rules"]="règle japonaise";
mxG.Z.fr["territory"]="territoire";
mxG.Z.fr["prisoners"]="prisonniers";
mxG.Z.fr["pass"]="passe";
mxG.Z.fr["stones"]="pierres";
mxG.Z.fr["last move"]="dernier coup";
mxG.Z.fr["komi"]="komi ";

mxG.G.prototype.getOwner=function(x,y)
{
	var xy;
	if (this.gor.inGoban(x,y))
	{
		xy=this.xy(x,y);
		if (this.visited4GetOwner[xy]) return 0;
		this.visited4GetOwner[xy]=1;
		if (this.scoreBan[x][y].modified=="E")
		{
			if (this.scoreBan[x][y].forced=="B") return 1;
			else if (this.scoreBan[x][y].forced=="W") return 2;
			else return this.getOwner(x-1,y)|this.getOwner(x+1,y)|this.getOwner(x,y-1)|this.getOwner(x,y+1);
		}
		if (this.scoreBan[x][y].modified=="B") return 1;
		if (this.scoreBan[x][y].modified=="W") return 2;
	}
	return 0;
};

mxG.G.prototype.toggleFriends=function(nat,x,y,enable)
{
	var xy,onat;
	onat=(nat=="B")?"W":"B";
	if (this.gor.inGoban(x,y))
	{
		xy=this.xy(x,y);
		if (this.visited4ToggleFriends[xy]) return;
		this.visited4ToggleFriends[xy]=1;
		if (this.scoreBan[x][y].initial==onat) return;
		if (this.scoreBan[x][y].forced==onat) return;
		if (this.scoreBan[x][y].forced==nat) return;
		if (this.scoreBan[x][y].initial==nat) this.scoreBan[x][y].modified=(enable?nat:"E");
		this.toggleFriends(nat,x-1,y,enable);
		this.toggleFriends(nat,x+1,y,enable);
		this.toggleFriends(nat,x,y-1,enable);
		this.toggleFriends(nat,x,y+1,enable);
	}
};

mxG.G.prototype.getTX=function()
{
	var TX=["TB","TW"];
	var aN,k,aLen,s,x,y,x1,y1,x2,y2,z;
	aN=this.cN4Score;
	for (z=0;z<7;z++)
	{
		if (aN.P[TX[z]]) aLen=aN.P[TX[z]].length;else aLen=0;
		for (k=0;k<aLen;k++)
		{
			s=aN.P[TX[z]][k];
			if (s.length==2)
			{
				x=s.c2n(0);
				y=s.c2n(1);
				this.scoreBan[x][y].marked=(TX[z]=="TB")?"B":"W";
			}
			else if (s.length==5)
			{
				x1=s.c2n(0);
				y1=s.c2n(1);
				x2=s.c2n(3);
				y2=s.c2n(4);
				for (x=x1;x<=x2;x++)
					for (y=y1;y<=y2;y++)
					{
						this.scoreBan[x][y].marked=(TX[z]=="TB")?"B":"W";
					}
			}
		}
	}
};

mxG.G.prototype.removeTX=function(a,b)
{
	// remove TM[ab] or TW[ab]
	var k,km,kp,TX=["TB","TW"],aN,v;
	aN=this.cN4Score;
	v=this.xy2s(a,b);
	for (kp=0;kp<TX.length;kp++)
	{
		if (aN.P[TX[kp]])
		{
			km=aN.P[TX[kp]].length;
			for (k=0;k<km;k++) if (aN.P[TX[kp]][k]==v) break;
			if (k<km) aN.TakeOff(TX[kp],k);
		}
	}
};

mxG.G.prototype.addTX=function(tx,a,b)
{
	// tx is "TB" or "TW"
	var aN,v;
	aN=this.cN4Score;
	v=this.xy2s(a,b);
	this.removeTX(a,b);
	if (aN.P[tx]) aN.P[tx].push(v);
	else aN.P[tx]=[v];
};

mxG.G.prototype.setTX=function()
{
	var i,j;
	for (i=1;i<=this.DX;i++)
		for (j=1;j<=this.DY;j++)
		{
			switch(this.scoreBan[i][j].computed)
			{
				case "B":this.addTX("TB",i,j);break;
				case "W":this.addTX("TW",i,j);break;
				default:this.removeTX(i,j);
			}
		}
};

mxG.G.prototype.resetTX=function()
{
	var i,j;
	for (i=1;i<=this.DX;i++)
		for (j=1;j<=this.DY;j++)
		{
			switch(this.scoreBan[i][j].marked)
			{
				case "B":this.addTX("TB",i,j);break;
				case "W":this.addTX("TW",i,j);break;
				default:this.removeTX(i,j);
			}
		}
};

mxG.G.prototype.initScoreBan=function()
{
	// scoreBan
	//   initial: goban state as is
	//   modified: keep trace of stones added/removed by the user
	//   computed: computed territories by maxiGos
	//   forced: keep trace of territories modifications made by the user
	var i,j,nat;
	this.scoreBan=[];
	for (i=1;i<=this.DX;i++)
	{
		this.scoreBan[i]=[];
		for (j=1;j<=this.DY;j++)
		{
			nat=this.gor.getBanNat(i,j);
			this.scoreBan[i][j]={initial:nat,modified:nat};
		}
	}
	this.getTX();
	this.justInitializedScoreBan=1;
};

mxG.G.prototype.setComputedScoreBan=function()
{
	var i,j,r;
	if (this.ephemeralScoreOn)
	{
		for (i=1;i<=this.DX;i++)
			for (j=1;j<=this.DY;j++)
			{
				if (this.scoreBan[i][j].forced) {this.scoreBan[i][j].computed=this.scoreBan[i][j].forced;}
				else if (this.scoreBan[i][j].modified!="E") this.scoreBan[i][j].computed="E";
				else
				{
					this.visited4GetOwner=[];
					r=this.getOwner(i,j);
					if ((r==1)||(r==2))
					{
						if (this.scoreBan[i][j].forced) {this.scoreBan[i][j].computed=this.scoreBan[i][j].forced;}
						else
						{
							if (r==1) this.scoreBan[i][j].computed="B";
							else this.scoreBan[i][j].computed="W";
						}
					}
					else
					{
						if (this.scoreBan[i][j].forced) {this.scoreBan[i][j].computed=this.scoreBan[i][j].forced;}
						else if (this.scoreBan[i][j].initial=="B") this.scoreBan[i][j].computed="W";
						else if (this.scoreBan[i][j].initial=="W") this.scoreBan[i][j].computed="B";
						else this.scoreBan[i][j].computed="E";
					}
				}
				if (this.justInitializedScoreBan&&this.scoreBan[i][j].marked)
				{
					if (this.scoreBan[i][j].marked!=this.scoreBan[i][j].computed)
					{
						this.scoreBan[i][j].forced=this.scoreBan[i][j].marked;
						this.scoreBan[i][j].computed=this.scoreBan[i][j].forced;
					}
				}
			}
	}
	else
	{
		for (i=1;i<=this.DX;i++)
			for (j=1;j<=this.DY;j++)
			{
				if (this.justInitializedScoreBan&&this.scoreBan[i][j].marked)
					this.scoreBan[i][j].forced=this.scoreBan[i][j].marked;
				if (this.scoreBan[i][j].forced) {this.scoreBan[i][j].computed=this.scoreBan[i][j].forced;}
				else this.scoreBan[i][j].computed="E";

			}
	}
	this.justInitializedScoreBan=0;
};

mxG.G.prototype.computeScore=function()
{
	if (!this.ephemeralScoreOn) return;
	var sw,sb,i,j,k,s,r,rs,komi,rules,pb,pw,ub,uw,nat,ib,iw,cb,cw,noPrisoner,ew;
	sb=0;
	sw=0;
	ib=0;
	iw=0;
	for (i=1;i<=this.DX;i++)
		for (j=1;j<=this.DY;j++)
		{
			switch(this.scoreBan[i][j].computed)
			{
				case "B":sb++;break;
				case "W":sw++;break;
			}
			switch(this.scoreBan[i][j].modified)
			{
				case "B":ib++;break;
				case "W":iw++;break;
			}
		}
	komi=this.getInfo("KM");
	if (komi) komi=parseFloat(komi); else komi=5.5;
	ub=0;
	uw=0;
	pw=0;
	pb=0;
	noPrisoner=0;
	for (k=1;k<=this.gor.play;k++)
	{
		nat=this.gor.nat[k];
		// remember: take care of pass moves
		if (nat=="B")
		{
			ub++;
			if (!this.gor.x[k]&&!this.gor.y[k]) pb++;
		}
		else if (nat=="W")
		{
			uw++;
			if (!this.gor.x[k]&&!this.gor.y[k]) pw++;
			if (this.gor.act[k]=="A") noPrisoner=1;//probably stone rearrangements!
		}
		else ;// "E": nothing to do since no "new" stone played
	}
	//cb=this.gor.getPrisoners("B"); // probably false when counting is started
	//cw=this.gor.getPrisoners("W"); // probably false when counting is started
	rules=this.getInfo("RU").toLowerCase();
	if ((rules=="chinese")||(rules=="ing")||(rules=="goe")||(rules=="nz")) r="C";
	else if (rules=="aga") r="A";
	else r="J";
	ew=0;
	if (noPrisoner)
	{
		cb=0;
		cw=0;
		pw=0;
		pb=0;
	}
	else
	{
		cb=uw-iw-pw;
		if ((r=="A")&&this.gor.play&&(this.gor.act[this.gor.play]=="")&&(this.gor.nat[this.gor.play]=="B")) ew=1;
		cw=ub-ib-pb;
	}
	switch(rules)
	{
		case "chinese":rs=this.local("chinese rules");break;
		case "aga":rs=this.local("AGA rules");break;
		case "ing":
		case "goe":rs=this.local("Ing rules");break;
		case "nz":rs=this.local("New-Zeland rules");break;
		default:rs=this.local("japanese rules");
	}
	s="<h1>"+this.local("Score")+" ("+rs+")</h1><div>";
	if (r=="J")
	{
		s+=this.local("Black:")+" "+sb+" ("+this.local("territory")+") "+" + "+cb+" ("+this.local("prisoners")+") "+" = "+(sb+cb);
		s+="<br>";
		s+=this.local("White:")+" "+sw+" ("+this.local("territory")+") "+" + "+cw+" ("+this.local("prisoners")+") "+" + "+komi+" ("+this.local("komi")+") "+" = "+(sw+cw+komi);
	}
	else if (r=="A")
	{
		s+=this.local("Black:")+" "+sb+" ("+this.local("territory")+") "+" + "+cb+" ("+this.local("prisoners")+") "+" + "+pw+" ("+this.local("pass")+") "+" + "+ew+" ("+this.local("last move")+") "+" = "+(sb+cb+pw+ew);
		s+="<br>";
		s+=this.local("White:")+" "+sw+" ("+this.local("territory")+") "+" + "+cw+" ("+this.local("prisoners")+") "+" + "+pb+" ("+this.local("pass")+") "+" + "+komi+" ("+this.local("komi")+") "+" = "+(sw+cw+pb+komi);
	}
	else // r=="C"
	{
		s+=this.local("Black:")+" "+sb+" ("+this.local("territory")+") "+" + "+ib+" ("+this.local("stones")+") "+" = "+(sb+ib);
		s+="<br>";
		s+=this.local("White:")+" "+sw+" ("+this.local("territory")+") "+" + "+iw+" ("+this.local("stones")+") "+" + "+komi+" ("+this.local("komi")+") "+" = "+(sw+iw+komi);
	}
	s+="</div>";
	this.scoreComment=s;
};

mxG.G.prototype.getComment4Score=function()
{
	return this.scoreComment;
};

mxG.G.prototype.toggleCanPlaceScore=function()
{
	//todo: score box if no comment box?
	var b;
	if (this.canPlaceScore)
	{
		if (this.ephemeralScoreOn)
		{
			this.getComment=this.exGetComment4Score;
			this.resetTX(this.cN4Score);
		}
		this.cN4Score=0;
		this.canPlaceScore=0;
		this.canPlaceVariation=this.initialCanPlaceVariationForScore;
		this.canPlaceGuess=this.initialCanPlaceGuessForScore;
		this.canPlaceSolve=this.initialCanPlaceSolveForScore;
		this.canPlaceEdit=this.initialCanPlaceEditForScore;	
		this.marksAndLabelsOn=this.initialmarksAndLabelsOnForScore;	
		b=this.getE("ScoreBtn");
		if (b) b.classList.remove("mxActivatedScoreBtn");//b not always exist
	}
	else
	{
		b=this.getE("ScoreBtn");
		if (b) b.classList.add("mxActivatedScoreBtn");//b not always exist
		this.cN4Score=this.cN;
		if (this.ephemeralScoreOn)
		{
			this.exGetComment4Score=this.getComment;
			this.getComment=this.getComment4Score;
		}
		this.canPlaceScore=1;
		this.initialCanPlaceVariationForScore=(this.canPlaceVariation?1:0);
		this.initialCanPlaceGuessForScore=(this.canPlaceGuess?1:0);
		this.initialCanPlaceSolveForScore=(this.canPlaceSolve?1:0);
		this.initialCanPlaceEditForScore=(this.canPlaceEdit?1:0);
		this.initialmarksAndLabelsOnForScore=(this.marksAndLabelsOn?1:0);
		this.canPlaceVariation=0;
		this.canPlaceGuess=0;
		this.canPlaceSolve=0;
		this.canPlaceEdit=0;
		this.marksAndLabelsOn=1;
		this.initScoreBan();
		this.setComputedScoreBan();
		this.setTX();
	}
};

mxG.G.prototype.doScore=function()
{
	this.toggleCanPlaceScore();
	if (this.canPlaceScore) this.computeScore();
	this.updateAll();
};

mxG.G.prototype.possibleOwner=function(x,y)
{
	var b,w;
	b=0;
	w=0;
	if (this.gor.inGoban(x-1,y))
	{
		if ((this.scoreBan[x-1][y].modified=="B")||(this.scoreBan[x-1][y].forced=="B"))  b+=3;
		else if ((this.scoreBan[x-1][y].modified=="W")||(this.scoreBan[x-1][y].forced=="W"))  w+=3;
	}
	if (this.gor.inGoban(x+1,y))
	{
		if ((this.scoreBan[x+1][y].modified=="B")||(this.scoreBan[x+1][y].forced=="B"))  b+=3;
		else if ((this.scoreBan[x+1][y].modified=="W")||(this.scoreBan[x+1][y].forced=="W"))  w+=3;
	}
	if (this.gor.inGoban(x,y-1))
	{
		if ((this.scoreBan[x][y-1].modified=="B")||(this.scoreBan[x][y-1].forced=="B"))  b+=3;
		else if ((this.scoreBan[x][y-1].modified=="W")||(this.scoreBan[x][y-1].forced=="W"))  w+=3;
	}
	if (this.gor.inGoban(x,y+1))
	{
		if ((this.scoreBan[x][y+1].modified=="B")||(this.scoreBan[x][y+1].forced=="B"))  b+=3;
		else if ((this.scoreBan[x][y+1].modified=="W")||(this.scoreBan[x][y+1].forced=="W"))  w+=3;
	}
	if (this.gor.inGoban(x-1,y-1))
	{
		if ((this.scoreBan[x-1][y-1].modified=="B")||(this.scoreBan[x-1][y-1].forced=="B"))  b++;
		else if ((this.scoreBan[x-1][y-1].modified=="W")||(this.scoreBan[x-1][y-1].forced=="W"))  w++;
	}
	if (this.gor.inGoban(x+1,y-1))
	{
		if ((this.scoreBan[x+1][y-1].modified=="B")||(this.scoreBan[x+1][y-1].forced=="B"))  b++;
		else if ((this.scoreBan[x+1][y-1].modified=="W")||(this.scoreBan[x+1][y-1].forced=="W"))  w++;
	}
	if (this.gor.inGoban(x-1,y+1))
	{
		if ((this.scoreBan[x-1][y+1].modified=="B")||(this.scoreBan[x-1][y+1].forced=="B"))  b++;
		else if ((this.scoreBan[x-1][y+1].modified=="W")||(this.scoreBan[x-1][y+1].forced=="W"))  w++;
	}
	if (this.gor.inGoban(x+1,y+1))
	{
		if ((this.scoreBan[x+1][y+1].modified=="B")||(this.scoreBan[x+1][y+1].forced=="B"))  b++;
		else if ((this.scoreBan[x+1][y+1].modified=="W")||(this.scoreBan[x+1][y+1].forced=="W"))  w++;
	}
	if (b>w) return "B";
	else if (w>b) return "W";
	else return "B";// todo: better choice?
};

mxG.G.prototype.checkScore=function(a,b)
{
	var po,opo;
	if ((this.scoreBan[a][b].initial=="E")||!this.ephemeralScoreOn)
	{
		// on clicked on an empty point
		// enforce change
		// 0 (po or opo)=>"E"=>po=>opo=>0 (po or opo) ...
		// 0 ("E")=>po=>opo=>0 ("E") ...
		if (this.scoreBan[a][b].initial=="E") po=this.possibleOwner(a,b);
		else po=(this.scoreBan[a][b].initial=="B")?"W":"B";
		opo=(po=="B")?"W":"B";
		if (this.scoreBan[a][b].forced)
		{
			if (this.scoreBan[a][b].computed==po) this.scoreBan[a][b].forced=opo;
			else if (this.scoreBan[a][b].computed==opo) this.scoreBan[a][b].forced=0;// not "E" here
			else this.scoreBan[a][b].forced=po;
		}
		else
		{
			if (this.scoreBan[a][b].computed==po) this.scoreBan[a][b].forced="E";
			else if (this.scoreBan[a][b].computed==opo) this.scoreBan[a][b].forced="E";
			else this.scoreBan[a][b].forced=po;
		}
	}
	else
	{
		// one clicked on a stone
		// enable/disable it and all friend stones that can be reached from it
		this.visited4ToggleFriends=[];
		if (this.scoreBan[a][b].modified=="E") this.toggleFriends(this.scoreBan[a][b].initial,a,b,1);
		else this.toggleFriends(this.scoreBan[a][b].initial,a,b,0);
	}
	this.setComputedScoreBan();
	this.setTX();
	this.computeScore();
	this.updateAll();
};

mxG.G.prototype.doClickScore=function(ev)
{
	if (this.isGobanDisabled()) return;
	if (this.canPlaceScore)
	{
		var c=this.getC(ev);
		if (!this.inView(c.x,c.y)) {this.plonk();return;}
		this.checkScore(c.x,c.y);		
	}
};

mxG.G.prototype.doKeydownGobanForScore=function(ev)
{
	var c;
	if (this.isGobanDisabled()) return;
	if (this.canPlaceScore&&this.gobanFocusVisible)
	{
		c=mxG.GetKCode(ev);
		if ((c==13)||(c==32))
		{
			this.checkScore(this.xFocus,this.yFocus);
			ev.preventDefault();
		}
	}
};

mxG.G.prototype.initScore=function()
{
	var e=this.gcn,k=this.k;
	e.getMClick=mxG.GetMClick;
	e.addEventListener("click",function(ev){mxG.D[k].doClickScore(ev);},false);
	if (this.gobanFocus) this.go.addEventListener("keydown",function(ev){mxG.D[k].doKeydownGobanForScore(ev);},false);
};

mxG.G.prototype.updateScore=function()
{
	if (this.canPlaceScore&&(this.cN!=this.cN4Score)) this.toggleCanPlaceScore();
	if (this.getE("ScoreBtn"))
	{
		if (this.gBox) this.disableBtn("Score");else this.enableBtn("Score");
	}
};

mxG.G.prototype.createScore=function()
{
	this.canPlaceScore=0; // to simplify tests
	if (this.scoreBtnOn)
	{
		this.write("<div class=\"mxScoreDiv\" id=\""+this.n+"ScoreDiv\">");
		this.addBtn({n:"Score",v:this.local("Score")});
		this.write("</div>");
	}
};

}