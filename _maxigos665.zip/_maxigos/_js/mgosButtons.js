// maxiGos v6.63 > mgosButtons.js

if (typeof mxG.G.prototype.createButtons=='undefined'){

mxG.G.prototype.refreshButtons=function()
{
	if (this.adjustButtonsWidth) this.adjust("Buttons","Width",this.adjustButtonsWidth);
	if (this.adjustButtonsHeight) this.adjust("Buttons","Height",this.adjustButtonsHeight);
};

mxG.G.prototype.createButtons=function()
{
	var a=(this.buttons?this.buttons.split(/[\s]*[,][\s]*/):[]),m,k,km=a.length;	
	this.write("<div class=\"mxButtonsDiv\" id=\""+this.n+"ButtonsDiv\">");
	for (k=0;k<km;k++)
	{
		m=a[k];
		if (this["add"+m+"Btn"]) this["add"+m+"Btn"]();
		else this.addBtn({n:m,v:this.local(m)});
	}
	this.write("</div>");
};

}