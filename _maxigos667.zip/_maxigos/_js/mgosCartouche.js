// maxiGos v6.63 > mgosCartouche.js

if (typeof mxG.G.prototype.createForumCartouche=='undefined'){

mxG.Z.fr["Black"]="Noir";
mxG.Z.fr["White"]="Blanc";
mxG.Z.fr[": "]=" : ";
mxG.Z.fr["Rank"]="Niv.";
mxG.Z.fr["Caps"]="Cap.";

mxG.G.prototype.drawStone4Cartouche=function(cx,img,x,y,d)
{
	cx.drawImage(img,x,y,d,d);
};

mxG.G.prototype.drawImagesContentInCartouche=function(d,d2)
{
	var cx,canDraw;
	canDraw=this.bigImg4Cartouche.B.canDraw&&this.bigImg4Cartouche.W.canDraw;
	if (this.smallStoneAsPrisonerLabelOn)
		canDraw=canDraw&&this.smallImg4Cartouche.B.canDraw&&this.smallImg4Cartouche.W.canDraw;
	if (!canDraw) {setTimeout(this.g+".drawImagesContentInCartouche("+d+","+d2+")",10);return;}
	this.getE("BlackCanvas").height=d;
	this.getE("BlackCanvas").width=d;
	cx=this.getE("BlackCanvas").getContext("2d");
	this.drawStone4Cartouche(cx,this.bigImg4Cartouche.B,0,0,d);
	this.getE("WhiteCanvas").height=d;
	this.getE("WhiteCanvas").width=d;
	cx=this.getE("WhiteCanvas").getContext("2d");
	this.drawStone4Cartouche(cx,this.bigImg4Cartouche.W,0,0,d);
	if (this.smallStoneAsPrisonerLabelOn)
	{
		this.getE("WhitePrisonersCanvas").height=d2;
		this.getE("WhitePrisonersCanvas").width=d2;
		cx=this.getE("WhitePrisonersCanvas").getContext("2d");
		this.drawStone4Cartouche(cx,this.smallImg4Cartouche.B,0,0,d2);
		this.getE("BlackPrisonersCanvas").height=d2;
		this.getE("BlackPrisonersCanvas").width=d2;
		cx=this.getE("BlackPrisonersCanvas").getContext("2d");
		this.drawStone4Cartouche(cx,this.smallImg4Cartouche.W,0,0,d2);
	}
};

mxG.G.prototype.di=function()
{
	return ((Math.min(255,mxG.GetPxrStyle(this.getE("BlackCanvas"),"fontSize")*2)>>1)<<1)-1;
};

mxG.G.prototype.drawImagesInCartouche=function()
{
	var d=this.di(),d2=(((d*0.4)>>1)<<1)+1;
	this.bigImg4Cartouche={B:this.setImg("B",d),W:this.setImg("W",d)};
	if (this.smallStoneAsPrisonerLabelOn) this.smallImg4Cartouche={B:this.setImg("B",d2),W:this.setImg("W",d2)};
	this.drawImagesContentInCartouche(d,d2);
	this.in3dOn4Cartouche=this.in3dOn;
};

mxG.G.prototype.initCartouche=function()
{
	this.drawImagesInCartouche();
};

mxG.G.prototype.updateCartouche=function()
{
	var s,aPlayer,aRank;
	this.getE("BlackPrisonersSpan").innerHTML=this.gor.getPrisoners("B");
	this.getE("WhitePrisonersSpan").innerHTML=this.gor.getPrisoners("W");
	aPlayer=this.getInfoS("PW");
	if (!aPlayer) aPlayer==this.local("White");
	aRank=this.getInfoS("WR");
	if (this.playerAndRankInSameElementOn)
		this.getE("WhitePlayerDiv").innerHTML=aPlayer+(aRank?" "+aRank:"");
	else
	{
		s="<div class=\"mxPlayerNameDiv\">"+aPlayer+"</div>";
		s+="<div class=\"mxRankContainerDiv\">";
		s+="<span class=\"mxRankLabelSpan\">"+this.local("Rank")+"</span>";
		if (aRank) s+="<span class=\"mxRankSpan\">"+this.build("Rank",aRank)+"</span>";
		s+="</div>";
		this.getE("WhitePlayerDiv").innerHTML=s;
	}
	aPlayer=this.getInfoS("PB");
	if (!aPlayer) aPlayer==this.local("Black");
	aRank=this.getInfoS("BR");
	if (this.playerAndRankInSameElementOn)
		this.getE("BlackPlayerDiv").innerHTML=aPlayer+(aRank?" "+aRank:"");
	else
	{
		s="<div class=\"mxPlayerNameDiv\">"+aPlayer+"</div>";
		s+="<div class=\"mxRankContainerDiv\">";
		s+="<span class=\"mxRankLabelSpan\">"+this.local("Rank")+"</span>";
		if (aRank) s+="<span class=\"mxRankSpan\">"+this.build("Rank",aRank)+"</span>";
		s+="</div>";
		this.getE("BlackPlayerDiv").innerHTML=s;
	}
};

mxG.G.prototype.refreshCartouche=function()
{
	// if page is displayed with "no style" option, need to minimize d
	var d=this.di();
	if (this.adjustCartoucheWidth) this.adjust("Cartouche","Width",this.adjustCartoucheWidth);
	if (this.adjustCartoucheHeight) this.adjust("Cartouche","Height",this.adjustCartoucheHeight);
	if ((this.getE("BlackCanvas").height!=d)||(this.in3dOn4Cartouche!=this.in3dOn)) this.drawImagesInCartouche();
};

mxG.G.prototype.createCartouche=function()
{
	this.write("<div class=\"mxCartoucheDiv\" id=\""+this.n+"CartoucheDiv\">");
	this.write("<div class=\"mxShortWhiteHeaderDiv\">");
	this.write("<canvas class=\"mxBigStoneCanvas\" height=\"31\" width=\"31\" id=\""+this.n+"WhiteCanvas\"></canvas>");
	this.write("<div class=\"mxPlayerDiv\" id=\""+this.n+"WhitePlayerDiv\"></div>");
	this.write("<div class=\"mxPrisonersContainerDiv\">");
	if (this.smallStoneAsPrisonerLabelOn)
	{
		this.write("<span class=\"mxPrisonersSpan\" id=\""+this.n+"WhitePrisonersSpan\">0</span>");
		this.write("<canvas class=\"mxSmallStoneCanvas\" height=\"13\" width=\"13\" id=\""+this.n+"WhitePrisonersCanvas\"></canvas>");
	}
	else
	{
		this.write("<span class=\"mxPrisonersLabelSpan\">"+this.local("Caps")+"</span>");
		this.write("<span class=\"mxPrisonersSpan\" id=\""+this.n+"WhitePrisonersSpan\">0</span>");
	}
	this.write("</div>");
	this.write("</div>");
	this.write("<div class=\"mxShortBlackHeaderDiv\">");
	this.write("<canvas class=\"mxBigStoneCanvas\" height=\"31\" width=\"31\" id=\""+this.n+"BlackCanvas\"></canvas>");
	this.write("<div class=\"mxPlayerDiv\" id=\""+this.n+"BlackPlayerDiv\"></div>");
	this.write("<div class=\"mxPrisonersContainerDiv\">");
	if (this.smallStoneAsPrisonerLabelOn)
	{
		this.write("<span class=\"mxPrisonersSpan\" id=\""+this.n+"BlackPrisonersSpan\">0</span>");
		this.write("<canvas class=\"mxSmallStoneCanvas\" height=\"13\" width=\"13\" id=\""+this.n+"BlackPrisonersCanvas\"></canvas>");
	}
	else
	{
		this.write("<span class=\"mxPrisonersLabelSpan\">"+this.local("Caps")+"</span>");
		this.write("<span class=\"mxPrisonersSpan\" id=\""+this.n+"BlackPrisonersSpan\">0</span>");
	}
	this.write("</div>");
	this.write("</div>");
	this.write("</div>");
};

}