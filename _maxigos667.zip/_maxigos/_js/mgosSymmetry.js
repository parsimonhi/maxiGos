// maxiGos v6.65 > mgosSymmetry.js

if (typeof mxG.G.prototype.createSymmetry=='undefined'){

mxG.Z.fr["Symmetry"]="Symétrie";
mxG.Z.fr["No symmetry"]="Pas de symétrie";
mxG.Z.fr["Horizontal mirror"]="Miroir horizontal";
mxG.Z.fr["Vertical mirror"]="Miroir vertical";
mxG.Z.fr["Rotate"]="Rotation";
mxG.Z.fr["Cancel"]="Annuler";
mxG.Z.fr["OK"]="OK";

mxG.G.prototype.doReplaceWhenSymmetry=function()
{
	var s=this.getE("ShowSgfTextArea").value;
	if (s!=this.sgfBeforeEdit)
	{
		this.mayHaveExtraTags=0;
		new mxG.P(this,this.getE("ShowSgfTextArea").value);
		this.backNode(this.rN.KidOnFocus());
		if (this.hasC("Tree")) this.initTree();
		this.updateAll();
	}
	this.hideGBox("ShowSgf");
};

mxG.G.prototype.doSymmetryOK=function()
{
	var e,s,z;
	if (this.hasC("Sgf"))
	{
		if (e=this.getE("NoSymmetryRadio")) {if (e.checked) this.symmetry=0;}
		if (e=this.getE("VerticalSymmetryRadio")) {if (e.checked) this.symmetry=1;}
		if (e=this.getE("HorizontalSymmetryRadio")) {if (e.checked) this.symmetry=2;}
		if (e=this.getE("RotateRadio"))
		{
			if (e.checked)
			{
				this.symmetry=3;
				if (this.DX!=this.DY)
				{
					this.rN.KidOnFocus().P["SZ"]=[this.DY+":"+this.DX];
					z=this.DY;
					this.DY=this.DX;
					this.DX=z;
				}
			}
		}
		s=this.buildSgf();
		this.symmetry=0;
		this.mayHaveExtraTags=0;
		new mxG.P(this,s);
		this.backNode(this.rN.KidOnFocus());
		if (this.hasC("Tree")) this.initTree();
	}
	this.hideGBox("ShowSymmetry");
};

mxG.G.prototype.buildSymmetry=function()
{
	var s="";
	if (this.hasC("Sgf"))
	{
		s+="<div class=\"mxP\">";
		s+="<input name=\"symmetryInput\" value=\"1\" type=\"radio\""+"id=\""+this.n+"NoSymmetryRadio\">";
		s+=" <label for=\""+this.n+"NoSymmetryRadio\">"+this.local("No symmetry")+"</label><br>";
		s+="<input name=\"symmetryInput\" value=\"1\" type=\"radio\""+"id=\""+this.n+"VerticalSymmetryRadio\">";
		s+=" <label for=\""+this.n+"VerticalSymmetryRadio\">"+this.local("Vertical mirror")+"</label><br>";
		s+="<input name=\"symmetryInput\" value=\"2\" type=\"radio\""+"id=\""+this.n+"HorizontalSymmetryRadio\">";
		s+=" <label for=\""+this.n+"HorizontalSymmetryRadio\">"+this.local("Horizontal mirror")+"</label><br>";
		s+="<input name=\"symmetryInput\" value=\"3\" type=\"radio\""+"id=\""+this.n+"RotateRadio\">";
		s+=" <label for=\""+this.n+"RotateRadio\">"+this.local("Rotate")+"</label><br>";
		s+="</div>";
	}
	return s;
};

mxG.G.prototype.setInputSymmetry=function()
{
	var e;
	if (e=this.getE("NoSymmetryRadio")) e.checked=(!this.symmetry);
	if (e=this.getE("VerticalSymmetryRadio")) e.checked=(this.symmetry==1);
	if (e=this.getE("HorizontalSymmetryRadio")) e.checked=(this.symmetry==2);
	if (e=this.getE("RotateRadio")) e.checked=(this.symmetry==3);
};

mxG.G.prototype.doSymmetry=function()
{
	if (this.gBox=="ShowSymmetry") {this.hideGBox("ShowSymmetry");return;}
	if (!this.getE("ShowSymmetryDiv"))
	{
		var s="";
		s+="<div class=\"mxShowContentDiv\">";
		s+="<h1>"+this.local("Symmetry")+"</h1>";
		s+=this.buildSymmetry();
		s+="</div>";
		s+="<div class=\"mxOKDiv\">";
		s+="<button type=\"button\" onclick=\""+this.g+".doSymmetryOK()\"><span>"+this.local("OK")+"</span></button>";
		s+="<button type=\"button\" onclick=\""+this.g+".hideGBox('ShowSymmetry')\"><span>"+this.local("Cancel")+"</span></button>";
		s+="</div>";
		this.createGBox("ShowSymmetry").innerHTML=s;
	}
	this.setInputSymmetry();
	this.showGBox("ShowSymmetry");
};

mxG.G.prototype.addSymmetryBtn=function()
{
	this.addBtn({n:"Symmetry",v:this.label("Symmetry","symmetryLabel")});
};

mxG.G.prototype.createSymmetry=function()
{
	if (this.symmetryBtnOn)
	{
		this.write("<div class=\"mxSymmetryDiv\" id=\""+this.n+"SymmetryDiv\">");
		this.addSymmetryBtn();
		this.write("</div>");
	}
};

}