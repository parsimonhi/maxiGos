// maxiGos v6.67 > mgosView.js

if (typeof mxG.G.prototype.createView=='undefined'){

mxG.Z.fr["2d/3d"]="2d/3d";
mxG.Z.fr["Zoom+"]="Agrandir";
mxG.Z.fr["No zoom"]="Normal";
mxG.Z.fr["Zoom-"]="Réduire";
mxG.Z.fr["Colors"]="Couleurs";
mxG.Z.fr["Default goban background"]="Fond du goban par défault";
mxG.Z.fr["Customized goban background"]="Fond du goban personnalisé";
mxG.Z.fr["Goban background (CSS color or JPG image):"]="Fond du goban (couleur CSS ou image JPG) :";
mxG.Z.fr["Line color (CSS color):"]="Couleur des lignes (couleur CSS) :";
mxG.Z.fr["Variation on focus color (CSS color):"]="Couleur de la variation ayant le focus (couleur CSS) :";
mxG.Z.fr["JPG images:"]="Images JPG :";

mxG.G.prototype.doColorsOK=function()
{
	var t,gbkt,gbk,lc,vofc;
	gbkt=this.getE("GobanBkRadio1Input").checked?1:2;
	if (gbkt==1) gbk=this.configGobanBk;
	else
	{
		gbk=this.getE("GobanBkInput").value;
		if (!gbk) gbk=this.configGobanBk;
		else if (gbk.match(/^[^\/]+\.jpg$/)) gbk="url(\""+this.configGobanBkImagePath+gbk+"\")";
		else if (gbk.match(/data:image\/(jpg|jpeg|png|gif);base64/))
			gbk="url(\""+gbk.replace(/^[\s\S]*data:image/,"data:image")+"\")";
	}
	lc=this.getE("LineColorInput").value;
	vofc=this.getE("VariationOnFocusColorInput").value;
	if (gbk!=this.gobanBk)
	{
		t=gbk.match(/^url\(/)?"image":"color";
		this.gobanBk=gbk;
		a=(t=="image")?"color":"image";
		mxG.AddCssRule("#"+this.n+"GobanCanvas {background-"+a+":none;}");
		mxG.AddCssRule("#"+this.n+"GobanCanvas {background-"+t+":"+this.gobanBk+";}");
	}
	this.lineColor=lc;
	this.variationOnFocusColor=vofc;
	this.hasToDrawWholeGoban=1;
	this.hideGBox("Colors");
	this.getE("ColorsForm").submit(); // just for autocompletion
};

mxG.G.prototype.doInputGobanBk=function()
{
	this.getE("GobanBkRadio2Input").checked=true;
};

mxG.G.prototype.doBlurGobanBk=function()
{
	var gbk,name;
	gbk=this.getE("GobanBkInput").value;
	if (gbk.match(/^[^\/]+\.jpg$/))
	{
		name=gbk.replace(/\.jpg$/,"");
		name=name.charAt(0).toUpperCase()+name.slice(1);
	}
	this.doUncheckGobanBkRadios();
	if (this.getE("GobanBkRadio"+name+"Input")) this.getE("GobanBkRadio"+name+"Input").checked=true;	
};

mxG.G.prototype.doChangeGobanBkRadio1=function()
{
	var gbk,name;
	if (this.configGobanBkImageName) gbk=this.configGobanBkImageName+".jpg";
	else if (this.configGobanBkImageBase64) gbk=this.configGobanBkImageBase64;
	else gbk=this.configGobanBk;
	this.getE("GobanBkInput").value=gbk;
	name=this.configGobanBkImageName;
	if (name)
	{
		name=name.charAt(0).toUpperCase()+name.slice(1);
		if (this.getE("GobanBkRadio"+name+"Input"))
			this.getE("GobanBkRadio"+name+"Input").checked=true;
	}
};

mxG.G.prototype.doChangeGobanBkRadio2=function()
{
	var name,path,gbk;
	gbk=this.getE("GobanBkInput").value;
	if (gbk.match(/^[^\/]+\.jpg$/))
	{
		name=gbk.replace(/\.jpg$/,"");
		name=name.charAt(0).toUpperCase()+name.slice(1);
	}
	if (this.getE("GobanBkRadio"+name+"Input")) this.getE("GobanBkRadio"+name+"Input").checked=true;
};

mxG.G.prototype.doChangeGobanBkRadio=function(s)
{
	this.getE("GobanBkInput").value=s.toLowerCase()+".jpg";
	this.getE("GobanBkRadio2Input").checked=true;
};

mxG.G.prototype.doUncheckGobanBkRadios=function()
{
	if (this.getE("GobanBkRadioBambooInput")) this.getE("GobanBkRadioBambooInput").checked=false;
	if (this.getE("GobanBkRadioBeechInput")) this.getE("GobanBkRadioBeechInput").checked=false;
	if (this.getE("GobanBkRadioBeech2Input")) this.getE("GobanBkRadioBeech2Input").checked=false;
	if (this.getE("GobanBkRadioCherryInput")) this.getE("GobanBkRadioCherryInput").checked=false;
	if (this.getE("GobanBkRadioKayaInput")) this.getE("GobanBkRadioKayaInput").checked=false;
	if (this.getE("GobanBkRadioOakInput")) this.getE("GobanBkRadioOakInput").checked=false;
	if (this.getE("GobanBkRadioPineInput")) this.getE("GobanBkRadioPineInput").checked=false;
	if (this.getE("GobanBkRadioRosewoodInput")) this.getE("GobanBkRadioRosewoodInput").checked=false;
	if (this.getE("GobanBkRadioTroyesInput")) this.getE("GobanBkRadioTroyesInput").checked=false;
};

mxG.G.prototype.doColors=function()
{
	var bk,s,a,e,gbk,name;
	if (this.hasC("Menu")) this.toggleMenu("View",0);
	if (this.gBox=="Colors") {this.hideGBox("Colors");return;}
	if (!this.getE("ColorsDiv"))
	{
		// use a form to store input values for autocompletion usage
		s="<form class=\"mxShowContentForm\" id=\""+this.n+"ColorsForm\" action=\"javascript:void(0)\" method=\"post\">";
		a=" tabindex=\"0\"";
		s+="<div class=\"mxShowContentDiv\""+a+">";
		s+="<h1>"+this.local("Colors")+"</h1>";
		s+="<div class=\"mxP\">";
		s+="<label class=\"mxGobanBkRadioInput\">";
		s+="<input class=\"mxGobanBkRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio1()\" name=\"GobanBkRadioInput\" value=\"1\" type=\"radio\" id=\""+this.n+"GobanBkRadio1Input\">";
		s+=" "+this.local("Default goban background")+"</label>";
		s+="<label class=\"mxGobanBkRadioInput\">";
		s+="<input class=\"mxGobanBkRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio2()\" name=\"GobanBkRadioInput\" value=\"2\" type=\"radio\" id=\""+this.n+"GobanBkRadio2Input\">";
		s+=" "+this.local("Customized goban background")+"</label>";
		s+="</div>";
		s+="<div class=\"mxP\">";
		s+="<label class=\"mxGobanBkColorTextInput\" for=\""+this.n+"GobanBkInput\">"+this.local("Goban background (CSS color or JPG image):");
		s+="<input type=\"text\" oninput=\""+this.g+".doInputGobanBk()\" onblur=\""+this.g+".doBlurGobanBk()\" id=\""+this.n+"GobanBkInput\">";
		s+="</label>";
		s+="</div>";
		if (!mxG.D[mxG.K].alone)
		{
			s+="<div class=\"mxP\">";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Bamboo')\" name=\"GobanBkRadioImageInput\" value=\"Bamboo\" type=\"radio\" id=\""+this.n+"GobanBkRadioBambooInput\">";
			s+=" "+this.local("Bamboo")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Beech')\" name=\"GobanBkRadioImageInput\" value=\"Beech\" type=\"radio\" id=\""+this.n+"GobanBkRadioBeechInput\">";
			s+=" "+this.local("Beech")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Beech2')\" name=\"GobanBkRadioImageInput\" value=\"Beech2\" type=\"radio\" id=\""+this.n+"GobanBkRadioBeech2Input\">";
			s+=" "+this.local("Beech2")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Cherry')\" name=\"GobanBkRadioImageInput\" value=\"Cherry\" type=\"radio\" id=\""+this.n+"GobanBkRadioCherryInput\">";
			s+=" "+this.local("Cherry")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Kaya')\" name=\"GobanBkRadioImageInput\" value=\"Kaya\" type=\"radio\" id=\""+this.n+"GobanBkRadioKayaInput\">";
			s+=" "+this.local("Kaya")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Oak')\" name=\"GobanBkRadioImageInput\" value=\"Oak\" type=\"radio\" id=\""+this.n+"GobanBkRadioOakInput\">";
			s+=" "+this.local("Oak")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Pine')\" name=\"GobanBkRadioImageInput\" value=\"Pine\" type=\"radio\" id=\""+this.n+"GobanBkRadioPineInput\">";
			s+=" "+this.local("Pine")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Rosewood')\" name=\"GobanBkRadioImageInput\" value=\"Rosewood\" type=\"radio\" id=\""+this.n+"GobanBkRadioRosewoodInput\">";
			s+=" "+this.local("Rosewood")+"</label>";
			s+="<label class=\"mxGobanBkImageRadioInput\">";
			s+="<input class=\"mxGobanBkImageRadioInput\" onchange=\""+this.g+".doChangeGobanBkRadio('Troyes')\" name=\"GobanBkRadioImageInput\" value=\"Troyes\" type=\"radio\" id=\""+this.n+"GobanBkRadioTroyesInput\">";
			s+=" "+this.local("Troyes")+"</label>";
			s+="</div>";
		}
		s+="<div class=\"mxP\">";
		s+="<label class=\"mxLineColorTextInput\" for=\""+this.n+"LineColorInput\">"+this.local("Line color (CSS color):");
		s+="<input type=\"text\" id=\""+this.n+"LineColorInput\">";
		s+="</label>";
		s+="</div>";
		s+="<div class=\"mxP\">";
		s+="<label class=\"mxVariationOnFocusColorTextInput\" for=\""+this.n+"VariationOnFocusColorInput\">"+this.local("Variation on focus color (CSS color):");
		s+="<input type=\"text\" id=\""+this.n+"VariationOnFocusColorInput\">";
		s+="</label>";
		s+="</div>";
		s+="</div>";
		s+="<div class=\"mxOKDiv\">";
		s+="<button type=\"button\" onclick=\""+this.g+".doColorsOK()\"><span>"+this.local("OK")+"</span></button>";
		s+="<button type=\"button\" onclick=\""+this.g+".hideGBox('Colors')\"><span>"+this.local("Cancel")+"</span></button>";
		s+="</div>";
		s+="</form>";
		this.createGBox("Colors").innerHTML=s;
	}
	if (this.configGobanBk===undefined)
	{
		// if gobanBk, a css rule using it was already added, thus don't need to use it here
		// don't use "background" here: complex or empty even if others are not
		bk=mxG.GetStyle(this.gcn,"backgroundImage");
		if (!bk||(bk=="none")) bk=mxG.GetStyle(this.gcn,"backgroundColor");
		this.configGobanBk=bk;
		this.gobanBk=bk;
	}
	if (this.configGobanBkImagePath===undefined)
	{
		if (this.configGobanBk.match(/^url\("?(.*\/)([^\/]+)\.jpg"?\)$/))
		{
			this.configGobanBkImagePath=this.configGobanBk.replace(/^url\("?(.*\/)([^\/]+)\.jpg"?\)$/,"$1");
			this.configGobanBkImageName=this.configGobanBk.replace(/^url\("?(.*\/)([^\/]+)\.jpg"?\)$/,"$2");
			this.configGobanBkImageBase64="";
		}
		else if (this.configGobanBk.match(/^url\("?data:image\/jpg;base64,[^"]*"?\)$/))
		{
			this.configGobanBkImagePath="";
			this.configGobanBkImageName="";
			this.configGobanBkImageBase64=this.configGobanBk.replace(/^url\(['"]?data:image\/(jpg|jpeg|png|gif);base64,[^'"]*['"]?\)$/,"$1");;
		}
		else
		{
			this.configGobanBkImagePath="";
			this.configGobanBkImageName="";
			this.configGobanBkImageBase64="";
		}
	}
	if (e=this.getE("GobanBkRadio1Input")) e.checked=(this.gobanBk==this.configGobanBk);
	if (e=this.getE("GobanBkRadio2Input")) e.checked=(this.gobanBk!=this.configGobanBk);
	if (this.gobanBk.match(/^url\("?(.*\/)([^\/]+)\.jpg"?\)$/))
	{
		gbk=this.gobanBk.replace(/^.*\/([^\/]+\.jpg)"?\)$/,"$1");
		name=gbk.replace(/\.jpg$/,"");
		name=name.charAt(0).toUpperCase()+name.slice(1);
	}
	else if (this.gobanBk.match(/^url\(['"]?data:image\/(jpg|jpeg|png|gif);base64,[^'"]*['"]?\)$/))
	{
		gbk=this.configGobanBk.replace(/^url\(['"]?(data:image\/(jpg|jpeg|png|gif);base64,[^'"]*)['"]?\)$/,"$1");
		name="";
	}
	else
	{
		gbk=this.gobanBk;
		name="";
	}
	this.doUncheckGobanBkRadios();
	if (name&&this.getE("GobanBkRadio"+name+"Input"))
		this.getE("GobanBkRadio"+name+"Input").checked=true;
	this.getE("GobanBkInput").value=gbk;
	this.getE("LineColorInput").value=this.lineColor;
	this.getE("VariationOnFocusColorInput").value=(this.variationOnFocusColor?this.variationOnFocusColor:"");
	this.showGBox("Colors");
};
mxG.G.prototype.doZoom=function(s)
{
	var e=this.gcn,n=5,d=this.d,d2;
	if (this.hasC("Menu")) this.toggleMenu("View",0);
	if (!this.d0) this.d0=d;
	do
	{
		n++;
		e.style.fontSize=n+"px";
		d2=2*Math.floor(mxG.GetPxStyle(e,"fontSize")*3/4)+1;
		if ((s=="+")&&((d+2)<=d2)) break;
		if ((s=="-")&&((d-2)<=d2)) break;
		if ((s=="=")&&(this.d0<=d2)) break;
	} while (n<42);
	this.refreshAll();
};

mxG.G.prototype.doZoomPlus=function(){this.doZoom("+");};
mxG.G.prototype.doNoZoom=function(){this.doZoom("=");};
mxG.G.prototype.doZoomMinus=function(){this.doZoom("-");};

mxG.G.prototype.doIn3d=function()
{
	if (this.hasC("Menu")) this.toggleMenu("View",0);
	this.in3dOn=this.in3dOn?0:1;
	var e=this.getE("GlobalBoxDiv");
	e.className=e.className.replace((this.in3dOn?"mxIn2d":"mxIn3d"),(this.in3dOn?"mxIn3d":"mxIn2d"));
	this.hasToDrawWholeGoban=1;
	this.exD=0;
	this.d=0;
	this.setD();
	if (this.hasC("Tree")) {this.hasToDrawTree=this.hasToDrawTree|1;this.dT=0;}
	if (this.hasC("Edit")) this.exEts=0;
	this.refreshAll();
};

mxG.G.prototype.addViewBtns=function()
{
	if (!this.hideViewIn3dBtn) this.addBtn({n:"In3d",v:this.local("2d/3d")});
	if (!this.hideViewZoomPlusBtn) this.addBtn({n:"ZoomPlus",v:this.local("Zoom+")});
	if (!this.hideViewNoZoomBtn) this.addBtn({n:"NoZoom",v:this.local("No zoom")});
	if (!this.hideViewZoomMinusBtn) this.addBtn({n:"ZoomMinus",v:this.local("Zoom-")});
	if (!this.hideViewColorsBtn) this.addBtn({n:"Colors",v:this.local("Colors")});
};

mxG.G.prototype.createView=function()
{
	if (this.viewBoxOn)
	{
		this.write("<div class=\"mxViewDiv\" id=\""+this.n+"ViewDiv\">");
		this.addViewBtns();
		this.write("</div>");
	}
};

}
