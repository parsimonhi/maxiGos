// maxiGos v6.63 > mgosVersion.js

if (typeof mxG.G.prototype.createVersion=='undefined'){

mxG.G.prototype.refreshVersion=function()
{
	if (this.adjustVersionWidth) this.adjust("Version","Width",this.adjustVersionWidth);
	if (this.adjustVersionHeight) this.adjust("Version","Height",this.adjustVersionHeight);
};

mxG.G.prototype.createVersion=function()
{
	this.write("<div class=\"mxVersionDiv\" id=\""+this.n+"VersionDiv\">");
	this.write("<span>maxiGos "+mxG.V+"</span>");
	this.write("</div>");
};

}