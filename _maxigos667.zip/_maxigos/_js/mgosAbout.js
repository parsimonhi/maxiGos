// maxiGos v6.63 > mgosAbout.js

if (typeof mxG.G.prototype.createAbout=='undefined'){

mxG.Z.fr["About"]="About";
mxG.Z.fr["Close"]="Fermer";

mxG.G.prototype.doAbout=function()
{
	if (this.gBox=="ShowAbout") {this.hideGBox("ShowAbout");return;}
	if (!this.getE("ShowAboutDiv"))
	{
		var s="";
		s+="<div class=\"mxShowContentDiv\">";
		s+="<h1>maxiGos "+mxG.V+"</h1>";
		s+="<p>Source: <a href=\"http://jeudego.org/maxiGos\">http://jeudego.org/maxiGos</a></p>";
		s+="<p>Theme: "+this.theme+"</p>";
		s+="<p>Configuration: "+this.config+"</p>";
		s+="<p>License: <a href=\"https://opensource.org/licenses/BSD-3-Clause\">BSD</a></p>";
		s+="<p>Copyright 1998-2017 François Mizessyn</p>";
		s+="</div>";
		s+="<div class=\"mxOKDiv\">";
		s+="<button type=\"button\" onclick=\""+this.g+".hideGBox('ShowAbout')\"><span>"+this.local("Close")+"</span></button>";
		s+="</div>";
		this.createGBox("ShowAbout").innerHTML=s;
	}
	this.showGBox("ShowAbout");
};

mxG.G.prototype.createAbout=function()
{
	if (this.aboutBtnOn)
	{
		this.write("<div class=\"mxAboutDiv\" id=\""+this.n+"AboutDiv\">");
		this.addBtn({n:"About",v:this.local("About")});
		this.write("</div>");
	}
};

}