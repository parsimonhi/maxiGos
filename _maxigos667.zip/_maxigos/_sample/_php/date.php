<?php $executionTimeOn=1;?>
<script>var date1=new Date();</script>
