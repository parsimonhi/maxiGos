<!DOCTYPE html>
<?php include "../_php/lang.php";?>
<html lang="<?php echo $mxL;?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<?php
if (isset($_GET["s"])) $style=$_GET["s"];else $style="3";
if (!in_array($style,array("1","2","3"))) $style="3";
include "../_php/date.php";
if ($mxL=="fr")
{
	$title="Exemple d'utilisation de maxiGos : ambiance tsumego.org";
	$problemOfTheDay="Problème du jour";
	$listOfProblem="Liste de problèmes";
}
else
{
	$title="Sample for maxiGos: tsumego.org style";
	$problemOfTheDay="Problem of the day";
	$listOfProblem="Problem list";
}
?>
<link rel="stylesheet" href="../_css/mini.css" type="text/css">

<style>
body {font-family:Arial,Helvetica,sans-serif;}

.superglobal1
{
	font-family:Verdana,Arial,Helvetica,sans-serif;
	font-size:12px;
	background:url(tatami.gif);
	margin:0 auto;
}
</style>
<title><?php print $title;?></title>
</head>
<body>
<?php $maxiGosDirPath="../../";include $maxiGosDirPath."_sample/_php/sample.php";?>
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php";?>
<div class="style">
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=1">Style 1</a>
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=2">Style 2</a>
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=3">Style 3</a>
</div>

<div class="superglobal3">
<div class="global">
<?php if ($mxL=="fr") {?>
<h1 class="header">Ambiance <a href="http://tsumego.org">tsumego.org</a></h1>
<?php } else {?>
<h1 class="header"><a href="http://tsumego.org">tsumego.org</a> style 3</h1>
<?php }?>
<div class="content">
<h2><?php print $problemOfTheDay;?></h2>
<div class="lpotd">
<div class="tpotd">
<h3>Tsumego</h3>
<div class="stars"><img src="etoile1.png" alt="etoile1"><img src="etoile1.png" alt="etoile1"><img src="etoile1.png" alt="etoile1"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"></div>
</div><!-- tpotd -->
<script src="../../_mgos/sgfplayer.php?sgf=<?php print urlencode("../_sample/_sgf/problem/p3-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;mxL=<?php print $mxL;?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumego3P.cfg");?>"></script>
</div><!-- lpotd -->
</div><!-- content -->
</div><!-- global -->
</div><!-- superglobal3 -->

<div class="superglobal2">
<div class="global">
<?php if ($mxL=="fr") {?>
<h1 class="header">Ambiance <a href="http://tsumego.org">tsumego.org</a> (le site a changé de style depuis que cet exemple a été conçu)</h1>
<?php } else {?>
<h1 class="header"><a href="http://tsumego.org">tsumego.org</a> style 2 (the site changed of style since this sample was built)</h1>
<?php }?>
<div class="content">
<h1 class="contentH1"><?php print $listOfProblem;?></h1>
<div class="l">
<div class="p">
<h1 style="display:inline;"><?php print ($mxL=="fr")?"Problème 1":(($mxL=="ja")?"第一題":(($mxL=="zh")?"第一题":(($mxL=="zh-tw")?"第一題":"Problem #1")));?></h1>
| <h2 style="display:inline;"><?php print ($mxL=="fr")?"Niveau : 1":(($mxL=="ja")?"初級":(($mxL=="zh")?"初级":(($mxL=="zh-tw")?"初級":"Level: 1")));?></h2>
<script src="../../_mgos/sgfplayer.php?sgf=<?php print urlencode("../_sample/_sgf/problem/p1-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;mxL=<?php print $mxL;?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumego2C.cfg");?>"></script>
</div>
<div class="p">
<h1 style="display:inline;"><?php print ($mxL=="fr")?"Problème 1":(($mxL=="ja")?"第一題":(($mxL=="zh")?"第一题":(($mxL=="zh-tw")?"第一題":"Problem #1")));?></h1>
| <h2 style="display: inline;"><?php print ($mxL=="fr")?"Niveau : 2":(($mxL=="ja")?中級:(($mxL=="zh")?"中级":(($mxL=="zh-tw")?"中級":"Level: 2")));?></h2>
<script src="../../_mgos/sgfplayer.php?sgf=<?php print urlencode("../_sample/_sgf/problem/p3-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;mxL=<?php print $mxL;?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumego2C.cfg");?>"></script>
</div>
</div>
<h1 class="contentH1"><?php print $problemOfTheDay;?></h1>
<div class="lpotd">
<div class="tpotd">
<h3>Tsumego</h3>
<div class="stars"><img src="etoile1.png" alt="etoile1"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"><img src="etoile2.png" alt="etoile2"></div>
</div><!-- tpotd -->
<script src="../../_mgos/sgfplayer.php?sgf=<?php print urlencode("../_sample/_sgf/problem/p2-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;mxL=<?php print $mxL;?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumego2P.cfg");?>"></script>
</div><!-- lpotd -->
</div><!-- content -->
</div><!-- global -->
</div><!-- superglobal2 -->

<div class="superglobal1">
<div class="global">
<?php if ($mxL=="fr") {?>
<h1 class="header">Ambiance <a href="http://tsumego.org">tsumego.org</a> (le site a changé de style depuis que cet exemple a été conçu)</h1>
<?php } else {?>
<h1 class="header"><a href="http://tsumego.org">tsumego.org</a> style 1 (the site changed of style since this sample was built)</h1>
<?php }?>
<div class="content">
<h1 class="contentH1"><?php print $listOfProblem;?></h1>
<div class="l">
<div class="p">
<script src="../../_mgos/sgfplayer.php?mxL=<?php print $mxL;?>&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p1-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumegoC.cfg");?>"></script>
</div><div class="p">
<script src="../../_mgos/sgfplayer.php?mxL=<?php print $mxL;?>&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p3-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumegoC.cfg");?>"></script>
</div>
</div>
<h1 class="contentH1"><?php print $problemOfTheDay;?></h1>
<script src="../../_mgos/sgfplayer.php?mxL=<?php print $mxL;?>&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p2-".((in_array($mxL,array("en","fr","ja","zh","zh-tw")))?$mxL:"en").".sgf");?>&amp;cfg=<?php print urlencode("../_sample/tsumego/tsumegoP.cfg");?>"></script>
</div><!-- content -->
</div><!-- global -->
</div><!-- superglobal1 -->

<div class="style">
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=1">Style 1</a>
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=2">Style 2</a>
<a href="tsumego.php?mxL=<?php echo $mxL;?>&amp;s=3">Style 3</a>
</div>
<div class="footer">
<?php $langList=array("en","fr","ja","zh","zh-tw");include "../_php/menu.php"; ?>
</div>
</body>
</html>
