<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
body
{
	font-family:Arial,sans-serif;
	font-size:14px;
	padding-left:0;
	padding-right:0;
	margin-left:0;
	margin-right:0;
}
</style>
</head>
<body>
<h1>Basic</h1>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/game/mn-bdg-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/basic.cfg");?>"></script>
<hr>
<h1>Comment</h1>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/game/mn-bdg-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/comment.cfg");?>"></script>
<hr>
<h1>Diagram</h1>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/miscellaneous/d_en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/diagram.cfg");?>"></script>
<hr>
<h1>Problems</h1>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p5-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/problem.cfg");?>"></script>
<br><br>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p6-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/problem.cfg");?>"></script>
<br><br>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/p1-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/problem2.cfg");?>"></script>
<br><br>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/problem/tactigo_en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/problem2.cfg");?>"></script>
<hr>
<h1>Castle Game</h1>
<script src="../../_mgos/sgfplayer.php?mxL=en&amp;sgf=<?php print urlencode("../_sample/_sgf/game/mn-bdg-en.sgf");?>&amp;cfg=<?php print urlencode("../_sample/goinblackandwhite/_cfg/castle.cfg");?>"></script>
</body>
</html>
