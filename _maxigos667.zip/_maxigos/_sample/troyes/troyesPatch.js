// maxiGos v6.63 > troyesPatch.js

if (typeof mxG.G.prototype.createTroyesPatch=='undefined'){

mxG.G.prototype.drawStone4Troyes=function(cx,nat,d)
{
	var r=d/2,c1,c2;
	cx.beginPath();
	cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
	if (this.in3dOn)
	{
		var zx=0.8,zy=0.5,x1,y1,rG;
		x1=zx*r;
		y1=zy*r;
		if (nat=="B")
		{
			rG=cx.createRadialGradient(0.5*r,0.5*r,0.05*r,0.5*r,0.5*r,2*r);
			rG.addColorStop(0,"#666");
			rG.addColorStop(0.2,"#222");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
		}
		else
		{
			rG=cx.createRadialGradient(x1,y1,0.2*r,x1,y1,2*r);
			rG.addColorStop(0,"#f7f4ef");
			rG.addColorStop(0.7,"#dcd5c7");
			rG.addColorStop(1,"#000");
			cx.fillStyle=rG;
			cx.fill();
			cx.beginPath();
			cx.arc(r,r,r-0.6*this.lw,0,Math.PI*2,false);
			cx.strokeStyle="rgba(0,0,0,0.1)";
			cx.lineWidth=this.lw;
			cx.stroke();
		}
	}
	else
	{
		if (nat=="B")
		{
			c1=this.blackStoneColor;
			c2=this.blackStoneBorderColor?this.blackStoneBorderColor:"#000";
		}
		else
		{
			c1=this.whiteStoneColor;
			c2=this.whiteStoneBorderColor?this.whiteStoneBorderColor:"#000";
		}
		cx.fillStyle=c1;
		cx.fill();
		cx.strokeStyle=c2;
		cx.lineWidth=this.lw;
		cx.stroke();
	}
};

mxG.G.prototype.createTroyesPatch=function()
{
	this.drawStone=this.drawStone4Troyes;
};

}
