<?php
// maxiGos v6.66 > path.php
// must be in the same folder as aloneLib.php and gosLib.php

// $gosRootRelativePath is a relative path from this script to "_maxigos" folder
// better to use a relative path as short as possible to avoid access file problem
// sometimes, it may be necessary to set it in the calling script (as sgfPlayer.php)

// $gosRootAbsolutePath is an absolute web path to "_maxigos" folder (ends by "_maxigos/")
// it is used in maxiGos ".js" code to retrieve external resources such as css files, images, ...
// sometimes, it may be necessary to set it in the calling script (as sgfPlayer.php)

function gosGetRootRelativePath()
{
	return "../";
}

function gosGetRootAbsolutePath()
{
	// assume the calling script (as sgfPlayer.php) is in a "_maxigos" subfolder
	// assume "_maxigos" folder has no subfolder called "_maxigos"
	// if not, set $gosRootAbsolutePath in the calling script
	$a=$_SERVER['PHP_SELF'];
	$pos=strrpos($a,"/_maxigos/");
	$gosDir=substr($a,0,$pos)."/_maxigos/";
	if (isset($_SERVER['HTTP_HOST']))
	{
		// add protocol and host name
		if (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'
    		||$_SERVER['SERVER_PORT']==443
    	    ||isset($_SERVER['HTTP_X_FORWARDED_PROTO'])&&$_SERVER['HTTP_X_FORWARDED_PROTO']==='https'
    	    ||isset($_SERVER['HTTP_X_FORWARDED_PORT'])&&$_SERVER['HTTP_X_FORWARDED_PORT']==443)
    		$protocol="https://";
    	else $protocol="http://";
		$gosDir=$protocol.$_SERVER['HTTP_HOST'].$gosDir;
	}
	return $gosDir;
}

// 1) relative path (in theory, used in .php files)

if (!isset($gosRootRelativePath)) $gosRootRelativePath=gosGetRootRelativePath();

// 2) absolute path (in theory, used in .js files)

if (!isset($gosRootAbsolutePath)) $gosRootAbsolutePath=gosGetRootAbsolutePath();
